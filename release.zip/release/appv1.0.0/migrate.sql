insert into role (name) values ('superadmin');
insert into role (name) values ('admin');
insert into role (name) values ('marketing');
insert into role (name) values ('business_analyst');
insert into admin (username,email,password) values ('admin','admin@clipse.ai','admin123');
insert into admin_user_roles (user_id, role_id) values (1,1);
insert into admin (username,email,password) values ('yeshu','yeshu.singh26@gmail.com','welcome123');
insert into admin_user_roles (user_id, role_id) values (2,2);

insert into entities (name,created,updated) values ('admin',NOW(),NOW());
insert into entities (name,created,updated) values ('user',NOW(),NOW());
insert into entities (name,created,updated) values ('role',NOW(),NOW());
insert into entities (name,created,updated) values ('campaign',NOW(),NOW());