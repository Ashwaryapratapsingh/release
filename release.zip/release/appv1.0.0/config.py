WTF_SCRF_ENABLED = True
SECRET_KEY = 'you-will-never-guess'
