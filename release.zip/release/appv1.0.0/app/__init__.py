#from __future__ import print_function
from flask import Flask, redirect, url_for, render_template, flash, json, render_template_string

from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user,\
    current_user
from oauth import OAuthSignIn
import requests
import pickle
import string
import csv
#from app import app
from flask import request, redirect, session
#from config import log
#from xml.dom import minidom
#from models import *
import base64
from controllers import landingController
from forms import LoginForm
from email_templates import welcome_email 
from email_templates import teaser_email
from utils import send_html_message, send_html_message_with_attachments
from datetime import date
from flask_user import login_required,roles_required
from werkzeug import secure_filename
import os
from math import ceil
from flask_paginate import Pagination
import datetime
import facebook
import icalendar
from icalendar import Calendar, Event
from pyicloud import PyiCloudService
#import datetime
from datetime import datetime
from pyexchange import Exchange2010Service, ExchangeNTLMAuthConnection
###
import json

import flask
import httplib2

from apiclient import discovery
from oauth2client import client
##

from urllib import  urlencode
import base64
import json
import time
from pytz import timezone

import atom.data
import gdata.data
import gdata.contacts.client
import gdata.contacts.data

import httplib2
import os
from apiclient import discovery
from oauth2client import client
from oauth2client import tools
from oauth2client.file import Storage

from rauth.service import OAuth2Service

from oauth2client.client import flow_from_clientsecrets
from oauth2client.client import OAuth2WebServerFlow

import urllib

import gdata.gauth
import atom.http_core
import gdata.contacts.service


import atom.data
import gdata.data
import gdata.contacts.client
import gdata.contacts.data
import atom.http_core



#from flask_user import login_required

#html_content = welcome_email.html_content

#print html_content
app = Flask(__name__)

app.config['WTF_SCRF_ENABLED'] = True
app.config['SECRET_KEY'] = 'top secret!'



#app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:p@ssword@localhost/clipse'

app.debug = True
app.config['SQLALCHEMY_ECHO'] = False
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:mysqlRoot@localhost/clipse'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False


app.config['OAUTH_CREDENTIALS'] = {
    'facebook': {
        'id': '136430806467361',
        'secret': '7ae9e482bf9e4e5ce357718e9b179a83'
    },
    'twitter': {
        'id': 'YrvBfrMpH7xcL4Xi8bJ38wtOv',
        'secret': 'MgpqDQmgHKEwMADMtNit42no0A6YleYffiI3hQelypbdTxBLpS'
    },
    'google': {
        'id' : '153230217988-j17rtl2ov5t5ph8v3vlc55a2prthr0bj.apps.googleusercontent.com',
        'secret' : '9JVg308NDJvi1bTymsoGVChS'
    },
    'linkedin': {
        'id' : '78f11g0huosy86',
        'secret' : 'HbELzX2t8WRiBlWo'
    }

}


db = SQLAlchemy(app)
lm = LoginManager(app)
lm.login_view = '/admin/login'
  
#user_manager = UserManager(db,app)

#html_content =  html_content %(link,link,link,ip)
'''
user: 1,2,3,4,5
admin: 1,2,3,4,5,
campaign: 1,2,3,4,5,6



'''

class Entity(UserMixin, db.Model):
    __tablename__ = 'entities'
    id = db.Column(db.Integer, primary_key=True)
    name =  db.Column(db.String(64), nullable=True)
    created = db.Column(db.TIMESTAMP, default=db.func.current_timestamp())
    updated= db.Column(db.TIMESTAMP, onupdate=db.func.current_timestamp())


class Campaign(UserMixin, db.Model):
    __tablename__ = 'campaigns'
    id = db.Column(db.Integer, primary_key=True)
    title =  db.Column(db.String(255), nullable=True)
    template = db.Column(db.String(255), nullable=True) #"yeshu.html"
    attachments = db.Column(db.Text, nullable=True)
    launched = db.Column(db.BOOLEAN, nullable=True, default = False)
    receipients =  db.Column(db.Text, nullable=True)
    created = db.Column(db.TIMESTAMP, default=db.func.current_timestamp())
    updated= db.Column(db.TIMESTAMP, onupdate=db.func.current_timestamp())


@app.route('/campaign/create', methods=['GET','POST'])
def create_campaign():
    try:
        if request.method == 'POST':
            
            title = request.form["title"]
            launched = request.form["launched"]
            f = request.files['template']         
            path = os.getcwd() + '/app/campaign/'
            f.save(path + secure_filename(f.filename))

            g = request.files['attachments']         
            path = os.getcwd() + '/app/campaign/attachments/'
            g.save(path + secure_filename(g.filename))


            receipients = request.form["recipients"]

            campaign = Campaign(title=title,template= f.filename ,attachments = g.filename , launched= launched,receipients = receipients  )
            db.session.add(campaign)
            db.session.commit()  
            ######################

            '''
            path = os.getcwd() + '/app/campaign/attachments/old_index_for_essta.txt'
            #path2 = os.getcwd() + '/app/campaign/attachments/nn.txt'

            attachments = [path]
            send_html_message_with_attachments("yeshu.singh26@gmail.com","TEST ATTACH","welcome deardvdv",attachments)
            '''
            ########################
            ret = {"status":200, "message": "Campaign created successfully"}
            return json.dumps(ret)
    except Exception,e:
        ret = {"status":500, "message": str(e)}
        return json.dumps(ret)


@app.route('/campaign/report', methods=['GET','POST'])
def campaign_report():
    try:
        
            
           
            end_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            start_time = datetime.datetime.now()-datetime.timedelta(days=2)
            start_time = start_time.strftime('%Y-%m-%d %H:%M:%S')
            
            campaign = Campaign.query.filter(Campaign.created < end_time).filter(Campaign.created > start_time).all()
            
            print campaign


            with open('campaign.csv', 'wb') as csvfile:
                csvwriter = csv.writer(csvfile, delimiter=',')
                
                csvwriter.writerow(['Title', 'created', 'template','attachments','receipients','launched'])
                for c in campaign:
                    csvwriter.writerow([c.title, c.created, c.template,c.attachments,c.receipients,c.launched])

            
            #db.session.add(campaign)
            #db.session.commit()  
            ######################
            
            '''
            path = os.getcwd() + '/app/campaign/attachments/old_index_for_essta.txt'
            #path2 = os.getcwd() + '/app/campaign/attachments/nn.txt'

            attachments = [path]
            send_html_message_with_attachments("yeshu.singh26@gmail.com","TEST ATTACH","welcome deardvdv",attachments)
            '''
            ########################
            ret = {"status":200, "message": "Campaign reports sent successfully"}
            return json.dumps(ret)
    except Exception,e:
        ret = {"status":500, "message": str(e)}
        return json.dumps(ret)





class Log(UserMixin, db.Model):
    __tablename__ = 'logs'
    id = db.Column(db.Integer, primary_key=True)
    entity_id = db.Column(db.Integer, nullable=True)
    entity_type =  db.Column(db.String(64), nullable=True)
    action = db.Column(db.Text, nullable=True)
    who_changed = db.Column(db.Integer, nullable=True)
    created = db.Column(db.TIMESTAMP, default=db.func.current_timestamp())
    updated= db.Column(db.TIMESTAMP, onupdate=db.func.current_timestamp())
    

class User(UserMixin, db.Model):
    __tablename__ = 'ClipseUsers'
    id = db.Column(db.Integer, primary_key=True)
    social_id = db.Column(db.String(64), nullable=True, unique=True)
    nickname = db.Column(db.String(64), nullable=True)
    email = db.Column(db.String(64), nullable=True)
    user_agent = db.Column(db.Text, nullable=True)
    ip = db.Column(db.String(64), nullable=True)
    created = db.Column(db.TIMESTAMP, default=db.func.current_timestamp())
    updated= db.Column(db.TIMESTAMP, onupdate=db.func.current_timestamp())
    subscribe = db.Column(db.BOOLEAN, nullable=True, default = True)
    blacklist = db.Column(db.BOOLEAN, nullable=True, default = False)


from math import ceil

# Pagintaion
class Pagination(object):

    def __init__(self, page, per_page, total_count):
        self.page = page
        self.per_page = per_page
        self.total_count = total_count

    @property
    def pages(self):
        return int(ceil(self.total_count / float(self.per_page)))

    @property
    def has_prev(self):
        return self.page > 1

    @property
    def has_next(self):
        return self.page < self.pages

    def iter_pages(self, left_edge=2, left_current=2,
                   right_current=5, right_edge=2):
        last = 0
        for num in xrange(1, self.pages + 1):
            if num <= left_edge or \
               (num > self.page - left_current - 1 and \
                num < self.page + right_current) or \
               num > self.pages - right_edge:
                if last + 1 != num:
                    yield None
                yield num
                last = num



@app.route('/classification_count', methods=['GET','POST'])
def classification_count():
#    start = request.args['start']
#    end = request.args['end']
#    print start, end
#    total_users = "select count(*) from ClipseUsers where created >= start and created <=end ;" 
#    blacklist_users= "select count(*) from ClipseUsers where blacklist = 1 and created >= start and created <=end ;"
#    subscribed_users= "select count(*) from ClipseUsers where created >=start and created <=end ;"
#    unsubscribed_users= "select count(*) from ClipseUsers where created >=start and created <=end ;"
#    res = db.engine.execute('select count(*) from ClipseUsers where created >= \"%s\" and created < \"%s\"' %(start, end))
#    for row in res:
#       return str(row[0])
    response = []
#    res = db.Column.execute('select count(*) from ClipseUsers where blacklist  ')
    total_users = db.engine.execute("select count(*) from ClipseUsers;")
    for row in total_users:
       total = str(row[0])
    subscribed_users = db.engine.execute("select count(*) from ClipseUsers where subscribe = 1;")
    for row in subscribed_users:
       subscribed = str(row[0])
    unsubscribed_users = db.engine.execute("select count(*) from ClipseUsers where subscribe = 0;")
    for row in unsubscribed_users:
       unsubscribed = str(row[0])
    blacklist_users = db.engine.execute("select count(*) from ClipseUsers where blacklist = 1;")
    for row in blacklist_users:
       blacklist = str(row[0])

    users= {'total': total, 'subscribed': subscribed, 'unsubscribed': unsubscribed, 'blacklist': blacklist }
#    return users
    response.append(users)
    return json.dumps(response)



@app.route('/users/<classification>', methods=['GET','POST'])
def getUsers(classification):


    def users():
        response = []
        users = db.engine.execute("select * from ClipseUsers;")  
        for user in users:
            response.append(list(user)) 
        return response


    def subscribed_users():
        response = []
        subscribed_users = db.engine.execute("select * from ClipseUsers where subscribe = 1;")
        for user in subscribed_users:
            response.append(list(user))
        return response

    def unsubscribed_users():
        response = []
        unsubscribed_users = db.engine.execute("select * from ClipseUsers where subscribe = 0;")
        for user in unsubscribed_users:
            response.append(list(user))
        return response

    def blacklist_users():
        response = []
        blacklist_users= db.engine.execute("select * from ClipseUsers where blacklist = 1;")
        for user in blacklist_users:
            response.append(list(user))
        return response

    classificationDict = {'users': users, 'subscribed': subscribed_users, 'unsubscribed': unsubscribed_users, 'blacklist': blacklist_users }

    userList = classificationDict[classification]()
    return json.dumps(userList)










#subscribed_users = db.engine.execute("select * from ClipseUsers where subscribe = 1;")
#for row in subscribed_users:
#    subscribed = str(row[0])
#unsubscribed_users = db.engine.execute("select * from ClipseUsers where suuscribe = 0;")
#for row in unsubscribed_users:
#    unsubscribed = str(row[0])
#blacklist_users = db.engine.execute("select * from ClipseUsers where blacklist = 1;")
#for row in blacklist_users:
#    blacklist = str(row[0])

    # for row in res:
    #     total_users = row[0]
    # res= db.engine.execute('select count(*) from ClipseUsers where blacklist = 1 and created >= start and created <=end ;')
    # for row in res:
    #     blacklist_users = row[0]
    # res= db.engine.execute('select count(*) from ClipseUsers where created >=start and created <=end ;')
    # for row in res:
    #     subscribed_users = row[0]
    # res= db.engine.execute('select count(*) from ClipseUsers where created >=start and created <=end ;')
    # for row in res:
    #     unsubscribed_users = row[0]
    
    # return str(count)
    #return (total_users,subscribed_users,blacklist_users, unsubscribed_users)


#def total_registration():
#    total_registration = "select * from ClipseUsers where created >= start and created <=end ; "

#def total_subscribed():
#    total_subscribed =  "selct * from ClipseUsers where created >=start and created <=end ;"

#def total_unsubscribed():
#    total_unsubscribed = "select * from ClipseUsers where created >=start and created <=end ;"

# def total_blacklist():
#    total_blacklist = "select * from ClipseUsers where created >=start and <=end ;"    



@app.route('/unsubscribe/<email>', methods=['GET','POST'])
def unsubscribe_mail(email):
        
    user = User.query.filter_by(email=email).first()
    if user:        
        user.subscribe = False
        db.session.commit()
    return render_template('unsubscribe.html')


@app.route('/sendemail', methods=['GET','POST'])
def send_mail():
        
    
    return render_template('email.html')


@app.route('/email', methods=['GET','POST'])
def email():
        
    
    return render_template('mailing.html')



@app.route('/', methods=['GET','POST'])
def teaser_page():
    #form = LoginForm()
    #SUBMIT CLICK

    if request.method == 'POST':
        email = request.form.get("email").lower()
        user = User.query.filter_by(email=email).first()
        if not user:
            print 'ip address of user=%s' %(request.remote_addr)
            print 'user agent = %s' %(request.user_agent)
            user = User(email=email,user_agent=str(request.user_agent),ip=str(request.remote_addr))
            db.session.add(user)
            db.session.commit()
            sub = "Welcome to Clipse"
            html_content =welcome_email.get_html_content(email)            
            send_html_message(email,sub,html_content)
            return  render_template('index.html',message="Thanks for registration",success = True)
        else:
            return  render_template('index.html',message="Email already exists")
        
      
    return render_template('index.html')


@app.route('/teaser', methods=['GET','POST'])
def teaser1_page():
    #form = LoginForm()
    #SUBMIT CLICK

    if request.method == 'POST':
        email = request.form.get("email").lower()
        user = User.query.filter_by(email=email).first()
        if not user:
            print 'ip address of user=%s' %(request.remote_addr)
            print 'user agent = %s' %(request.user_agent)
            user = User(email=email,user_agent=str(request.user_agent),ip=str(request.remote_addr))
            db.session.add(user)
            db.session.commit()
            sub = "Welcome to Clipse"
            html_content =welcome_email.get_html_content(email)            
            send_html_message(email,sub,html_content)
            return  render_template('teaser1.html',message="Thanks for registration",success = True)
        else:
            return  render_template('teaser1.html',message="Email already exists")
        
      
    return render_template('teaser1.html')


@app.route('/contact', methods=['GET','POST'])
def contact_page():
    #form = LoginForm()
    #SUBMIT CLICK

    if request.method == 'POST':
        email = request.form.get("email")
        user = User.query.filter_by(email=email).first()
        if not user:
            print 'ip address of user=%s' %(request.remote_addr)
            print 'user agent = %s' %(request.user_agent)
            user = User(email=email,user_agent=str(request.user_agent),ip=str(request.remote_addr))
            db.session.add(user)
            db.session.commit()
            sub = "Welcome to Clipse"
            html_content =welcome_email.get_html_content(email)            
            send_html_message(email,sub,html_content)
            return  render_template('contactus.html',message="Thanks for registration",success = True)
        else:
            return  render_template('contactus.html',message="Email already exists")
        
      
    return render_template('contactus.html')
    

@lm.user_loader
def load_user(id): 
    return User.query.get(int(id))


@app.route('/sociallogin')
def fb_index():
    return render_template('social.html')


@app.route('/logout')
def logout():
    logout_user()
    if flask.session.has_key('credentials'):
        flask.session.pop('credentials')
    return redirect(url_for('index'))


@app.route('/authorize/<provider>')
def oauth_authorize(provider):
    if not current_user.is_anonymous:
        return redirect(url_for('index'))
    oauth = OAuthSignIn.get_provider(provider)
    return oauth.authorize()


@app.route('/callback/<provider>')
def oauth_callback(provider):
    if not current_user.is_anonymous:
        return redirect(url_for('index'))
    oauth = OAuthSignIn.get_provider(provider)
    data = oauth.callback()
    print data, provider
    social_id = data[0]
    username = data[1]
    email = data[2]
    if social_id is None:
        flash('Authentication failed.')
        return redirect(url_for('index'))
    user = User.query.filter_by(social_id=social_id).first()
    if not user:
        user = User(social_id=social_id, nickname=username)
        db.session.add(user)
        db.session.commit()
    login_user(user, True)
    return redirect(url_for('index'))



@app.route('/')
def home():
    if not session.get('logged_in'):
        return render_template('login.html')
    else:
        return "Hello !  <a href='/logout'>Logout</a>"
 

 
@app.route("/admin/logout")
def admin_logout():
    session['logged_in'] = False
    return  render_template('adminlogin2.html',message="logout")


@app.route('/admin/login', methods=['GET','POST'])
def do_admin_login():
    if request.method == 'POST':
        password = request.form['password']
        username = request.form['username']  
        print username, password  
        admin = Admin.query.filter_by(username=username).filter_by(password=password).first()
        #query = "select * from admin where username= '%s' and password= '%s';" %(username,password)
        #print query
        #ret = db.engine.execute(query)
        #print ret
        flag = 0
        if admin:
            flag = 1

        if flag == 1 :
            session['logged_in'] = True
            session['logged_in_user_id'] = admin.id
            print "logged in"
            return  redirect(url_for('.render_dashboard'))
        else:
            #print "wrong pass"
            #return  render_template('adminlogin2.html',message="wrong password")
            return render_template("adminlogin2.html",message="Wrong Credentials. Please try again")
            
    return render_template("adminlogin2.html")


@app.route('/admin/dashboard')
def render_dashboard():
    response = []
    total_users = db.engine.execute("select count(*) from ClipseUsers;")
    for row in total_users:
       total = str(row[0])
    subscribed_users = db.engine.execute("select count(*) from ClipseUsers where subscribe = 1;")
    for row in subscribed_users:
       subscribed = str(row[0])
    unsubscribed_users = db.engine.execute("select count(*) from ClipseUsers where subscribe = 0;")
    for row in unsubscribed_users:
       unsubscribed = str(row[0])
    blacklist_users = db.engine.execute("select count(*) from ClipseUsers where blacklist = 1;")
    for row in blacklist_users:
       blacklist = str(row[0])

    users= {'total': total, 'subscribed': subscribed, 'unsubscribed': unsubscribed, 'blacklist': blacklist }
#    return users
    response.append(users)
    return render_template('dashboard.html', count= response[0])
    
    


class Role(db.Model):
    #__tablename__ = 'Roles'
    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(50), unique=True)


class Admin(db.Model, UserMixin):
    #__tablename__ = 'ClipseAdmins'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), nullable=True)
    email = db.Column(db.String(55), nullable=True, unique=True)
    password = db.Column(db.String(255), nullable=False)
    roles = db.relationship('Role', secondary='admin_user_roles',
            backref=db.backref('admin', lazy='dynamic'))



class AdminUserRoles(db.Model):
    #__tablename__ = 'ClipseAdminRoles'
    id = db.Column(db.Integer(), primary_key=True)
    user_id = db.Column(db.Integer(), db.ForeignKey('admin.id', ondelete='CASCADE'))
    role_id = db.Column(db.Integer(), db.ForeignKey('role.id', ondelete='CASCADE'))


@app.route("/test")
def hellotest():
    return render_template("index.html")

@app.route('/add/user', methods = ['POST'])
def api_message():    
    try:
        
        resp = eval(request.data)    
        username =  resp['username']  
        password =  resp["password"]
        mail =  resp["email"]
        role =  resp["role"]
        print role
        print mail
        print username
        print password
        user1 = Admin(username= username, email= mail, password = password)
        #role1 = Role(name=role)
        role1 =   Role.query.filter_by(name=role).first()
        user1.roles.append(role1)

        # Store user and roles
        db.session.add(user1)
        db.session.commit()
        ###########################################
        admin_object =  Admin.query.filter_by(email=mail).first()
        entity_id =  admin_object.id
        entity_type =  'admin'
        action = "add"
        who_changed = session["logged_in_user_id"]#session  to be fetched from session
    

        user = Log(entity_id= entity_id,entity_type= entity_type, action= action,who_changed=who_changed )
        db.session.add(user)
        db.session.commit()
        ###########################################
        ret = {"status":200, "message": "User saved successfully"}
        return json.dumps(ret)
    except Exception,e:
        ret = {"status":500, "message": str(e)}
        return json.dumps(ret)




#If this function returns 1, it means special character exists
def testforspecialchar(mystr):
    special_list = string.punctuation
    flag = 0 # if special charcter does not exit
    for char in special_list:
        if char in mystr:
            flag =  1
            break
    return flag


# To reset password
@app.route('/admin/resetpassword', methods=['POST'])
def resetpassword():
    
    if request.method == 'POST':
            mydict = eval(request.data)
            email = mydict["email"]
            new_password = mydict["password"]

            admin = Admin.query.filter_by(email=email).first()
            if admin:
                if len(new_password) < 5:
                    ret = {"status":500, "message": "password cannot be less than 5 characters"}
                    return json.dumps(ret)
                elif testforspecialchar(new_password) == 0:
                    ret = {"status":500, "message": "password should contain minimum 1 special character"}
                    return json.dumps(ret)
                else:
                    admin.password = new_password
                    db.session.add(admin)
                    db.session.commit()
                    ret = {"status":200, "message": "Password reset successfully"}
                    return json.dumps(ret)
            else:
                ret = {"status":500, "message": "No such email exists"}
                return json.dumps(ret)
           
            
            
        
# To send bulk emails
#def send_bulk_email(to,subject,body)
@app.route('/send_bulk_email', methods = ['POST'])
def send_bulk_email():
    #{"email_list":["ashu_001007@yahoo.com","yeshu.singh26@gmail.com"], "name":["ashu","yeshu"]}
    try:
        #mydict = eval(request.data)
        
        salutation = request.form["salutation"]
        

        content = request.form["content"]
        
        signature =  request.form["signature"]
        
        emails = request.form["email"]#mydict["email_list"]
        subject =  request.form["subject"]
        message = salutation + "\n" + content + "\n\n" + signature

        message = message.replace("\n","<br>")
        
        #campaign_title =  request.form["title"] #mydict["campaign_title"]
        #message = request.form["message"]#mydict["message"]
        emails = emails.split(",")
        emails = [elem.strip() for elem in emails]

        '''
        f = request.files['file']
        if f:
            message = salutation + "\n" + f.read() + "\n\n" + signature
        '''
            
           

        
        #names = mydict["name"]
        for i in range(0,len(emails)):
            #name = names[i]
            email = emails[i]

            subject = subject
            body = message     #This is to send text email.
            #body =  teaser_email.get_html_content(email)  #This is to send email template.
            send_html_message(email,subject,body)
        return render_template("mailing.html",message="Bulk email successfully sent",success="true")
        
    except Exception,e:
        ret = {"status":500,"message":str(e)}
        return json.dumps(ret)



# To upload files
@app.route('/upload')
def upload_file():
   return render_template('upload.html')



@app.route('/uploader', methods = ['GET', 'POST'])
def uploader_file():
    if request.method == 'POST':
      print request.headers
      f = request.files['file']
         
      path = os.getcwd() + '/app/campaign/'
      f.save(path + secure_filename(f.filename))
      
    return render_template("email.html",message="File uploaded successfully",success="true")


# To search 
@app.route('/search', methods=['GET', 'POST'])
def search():
    if request.method == "POST":
        response = []
        print request.form['search']
        #search = db.engine.execute("select * from ClipseUsers where email like '%%s%'" %(request.form['search']))
        searchstr = "select * from ClipseUsers where email like '%%" + str(request.form['search']) + "%%';"
        print searchstr
        search = db.engine.execute(searchstr)
        
        for user in search:
            response.append(list(user))
        return json.dumps(response)


    return render_template('search.html')


# Pagination
def url_for_other_page(page,per_page):
    args = request.view_args.copy()
    args['page'] = page
    args['per_page'] = per_page
    return url_for(request.endpoint, **args)

app.jinja_env.globals['url_for_other_page'] = url_for_other_page



#  To Search , Pagination , Date time breakdown
@app.route('/search/total',methods=['GET', 'POST'])
def search_total():
    if request.method == "POST":
        search_text = "%%" + request.form["search"] + "%%"
        session["search_text"] = search_text
        from_time =  request.form["from"]
        to_time =  request.form["to"]
        session["from_time"] = request.form["from"]
        session["to_time"] = request.form["to"]
    else:
        search_text = session["search_text"]
        from_time = session["from_time"]
        to_time = session["to_time"]
    page = request.args["page"]
    items_per_page =  request.args["per_page"]
    #ret_users = User.query.filter(User.email.like(search_text)).filter(User.created <= to_time).filter(User.created >= from_time).paginate(int(page),int(items_per_page),False).items
        
    #ret_users = User.query.paginate(int(page),int(items_per_page),False).items    
    #pagination = Pagination(int(page), int(items_per_page), int(User.query.filter(User.email.like(search_text)).count()))
    

    if from_time == '' and to_time == '':
        #case when neither from_time nor to_time
        ret_users = User.query.filter(User.email.like(search_text)).paginate(int(page),int(items_per_page),False).items
        
        pagination = Pagination(int(page), int(items_per_page), int(User.query.filter(User.email.like(search_text)).count()))
    elif from_time == '':
        #case of to_time
        ret_users = User.query.filter(User.email.like(search_text)).filter(User.created < to_time).paginate(int(page),int(items_per_page),False).items
        
        pagination = Pagination(int(page), int(items_per_page), int(User.query.filter(User.email.like(search_text)).filter(User.created < to_time).count()))
    
    elif to_time == '':
        #case of from_time
        ret_users = User.query.filter(User.email.like(search_text)).filter(User.created > from_time).paginate(int(page),int(items_per_page),False).items
        
        pagination = Pagination(int(page), int(items_per_page), int(User.query.filter(User.email.like(search_text)).filter(User.created > from_time).count()))
    
    else:
        #case of both from_time and to_time
        ret_users = User.query.filter(User.email.like(search_text)).filter(User.created > from_time).filter(User.created < to_time).paginate(int(page),int(items_per_page),False).items
        
        pagination = Pagination(int(page), int(items_per_page), int(User.query.filter(User.email.like(search_text)).filter(User.created > from_time).filter(User.created < to_time).count()))

    return render_template('listing.html',users=ret_users,pagination=pagination,request_url="total")


@app.route('/search/subscribed',methods=['GET', 'POST'])
def search_subscribed():
    
    if request.method == "POST":
        search_text = "%%" + request.form["search"] + "%%"
        session["search_text"] = search_text
        from_time =  request.form["from"]
        to_time =  request.form["to"]  

        session["from_time"] = request.form["from"]
        session["to_time"] = request.form["to"]
    else:
        
        search_text = session["search_text"]
        from_time = session["from_time"]
        to_time = session["to_time"]

    page = request.args["page"]
    items_per_page =  request.args["per_page"]

    #ret_users = User.query.filter_by(subscribe=1).paginate(int(page),int(items_per_page),False).items

    if from_time == '' and to_time == '':
        #case when neither from_time nor to_time
        ret_users = User.query.filter_by(subscribe=1).filter(User.email.like(search_text)).paginate(int(page),int(items_per_page),False).items
        
        pagination = Pagination(int(page), int(items_per_page), int(User.query.filter_by(subscribe=1).filter(User.email.like(search_text)).count()))
    elif from_time == '':
        #case of to_time
        ret_users = User.query.filter_by(subscribe=1).filter(User.email.like(search_text)).filter(User.created < to_time).paginate(int(page),int(items_per_page),False).items
        
        pagination = Pagination(int(page), int(items_per_page), int(User.query.filter_by(subscribe=1).filter(User.email.like(search_text)).filter(User.created < to_time).count()))
    
    elif to_time == '':
        #case of from_time
        ret_users = User.query.filter_by(subscribe=1).filter(User.email.like(search_text)).filter(User.created > from_time).paginate(int(page),int(items_per_page),False).items
        
        pagination = Pagination(int(page), int(items_per_page), int(User.query.filter_by(subscribe=1).filter(User.email.like(search_text)).filter(User.created > from_time).count()))
    
    else:
        #case of both from_time and to_time
        ret_users = User.query.filter_by(subscribe=1).filter(User.email.like(search_text)).filter(User.created > from_time).filter(User.created < to_time).paginate(int(page),int(items_per_page),False).items
        
        pagination = Pagination(int(page), int(items_per_page), int(User.query.filter_by(subscribe=1).filter(User.email.like(search_text)).filter(User.created > from_time).filter(User.created < to_time).count()))
    

    return render_template('listing.html',users=ret_users,pagination=pagination,request_url="subscribed")


@app.route('/search/unsubscribed',methods=['GET', 'POST'])
def search_unsubscribed():
    
    if request.method == "POST":
        search_text = "%%" + request.form["search"] + "%%"
        session["search_text"] = search_text
        from_time =  request.form["from"]
        to_time =  request.form["to"]
        session["from_time"] = request.form["from"]
        session["to_time"] = request.form["to"]
    else:
        search_text = session["search_text"]
        from_time = session["from_time"]
        to_time = session["to_time"]

    page = request.args["page"]
    items_per_page =  request.args["per_page"]
    #ret_users = User.query.filter_by(subscribe=1).paginate(int(page),int(items_per_page),False).items


    if from_time == '' and to_time == '':
        #case when neither from_time nor to_time
        ret_users = User.query.filter_by(subscribe=0).filter(User.email.like(search_text)).paginate(int(page),int(items_per_page),False).items
        
        pagination = Pagination(int(page), int(items_per_page), int(User.query.filter_by(subscribe=0).filter(User.email.like(search_text)).count()))
    elif from_time == '':
        #case of to_time
        ret_users = User.query.filter_by(subscribe=0).filter(User.email.like(search_text)).filter(User.created < to_time).paginate(int(page),int(items_per_page),False).items
        
        pagination = Pagination(int(page), int(items_per_page), int(User.query.filter_by(subscribe=0).filter(User.email.like(search_text)).filter(User.created < to_time).count()))
    
    elif to_time == '':
        #case of from_time
        ret_users = User.query.filter_by(subscribe=0).filter(User.email.like(search_text)).filter(User.created > from_time).paginate(int(page),int(items_per_page),False).items
        
        pagination = Pagination(int(page), int(items_per_page), int(User.query.filter_by(subscribe=0).filter(User.email.like(search_text)).filter(User.created > from_time).count()))
    
    else:
        #case of both from_time and to_time
        ret_users = User.query.filter_by(subscribe=0).filter(User.email.like(search_text)).filter(User.created > from_time).filter(User.created < to_time).paginate(int(page),int(items_per_page),False).items
        
        pagination = Pagination(int(page), int(items_per_page), int(User.query.filter_by(subscribe=0).filter(User.email.like(search_text)).filter(User.created > from_time).filter(User.created < to_time).count()))
    
    
    return render_template('listing.html',users=ret_users,pagination=pagination,request_url="unsubscribed")


@app.route('/search/blacklist',methods=['GET', 'POST'])
def search_blacklist():
    
    if request.method == "POST":
        search_text = "%%" + request.form["search"] + "%%"
        session["search_text"] = search_text
        from_time =  request.form["from"]
        to_time =  request.form["to"]
        session["from_time"] = request.form["from"]
        session["to_time"] = request.form["to"]
    else:
        search_text = session["search_text"]
        from_time = session["from_time"]
        to_time = session["to_time"]

    page = request.args["page"]
    items_per_page =  request.args["per_page"]
    #ret_users = User.query.filter_by(subscribe=1).paginate(int(page),int(items_per_page),False).items


    if from_time == '' and to_time == '':
        #case when neither from_time nor to_time
        ret_users = User.query.filter_by(blacklist=1).filter(User.email.like(search_text)).paginate(int(page),int(items_per_page),False).items
        
        pagination = Pagination(int(page), int(items_per_page), int(User.query.filter_by(blacklist=1).filter(User.email.like(search_text)).count()))
    elif from_time == '':
        #case of to_time
        ret_users = User.query.filter_by(blacklist=1).filter(User.email.like(search_text)).filter(User.created < to_time).paginate(int(page),int(items_per_page),False).items
        
        pagination = Pagination(int(page), int(items_per_page), int(User.query.filter_by(blacklist=1).filter(User.email.like(search_text)).filter(User.created < to_time).count()))
    
    elif to_time == '':
        #case of from_time
        ret_users = User.query.filter_by(blacklist=1).filter(User.email.like(search_text)).filter(User.created > from_time).paginate(int(page),int(items_per_page),False).items
        
        pagination = Pagination(int(page), int(items_per_page), int(User.query.filter_by(blacklist=1).filter(User.email.like(search_text)).filter(User.created > from_time).count()))
    
    else:
        #case of both from_time and to_time
        ret_users = User.query.filter_by(blacklist=1).filter(User.email.like(search_text)).filter(User.created > from_time).filter(User.created < to_time).paginate(int(page),int(items_per_page),False).items
        
        pagination = Pagination(int(page), int(items_per_page), int(User.query.filter_by(blacklist=1).filter(User.email.like(search_text)).filter(User.created > from_time).filter(User.created < to_time).count()))
    
    return render_template('listing.html',users=ret_users,pagination=pagination,request_url="blacklist",blacklist=true)




@app.route('/admin/total')
def admin_total():
    #app.jinja_env.globals['request_url'] = "total"
    page = request.args["page"]
    items_per_page = request.args["per_page"]    
    ret_users = User.query.paginate(int(page),int(items_per_page),False).items    
    pagination = Pagination(int(page), int(items_per_page), int(User.query.count()))
    return render_template('listing.html',users=ret_users,pagination=pagination,request_url = "total")

@app.route('/admin/subscribed')
def admin_subscribed():    
    #app.jinja_env.globals['request_url'] = "subscribed"
    #users = User.query.filter_by(subscribe=1)
    page = request.args["page"]
    items_per_page = request.args["per_page"]    
    ret_users = User.query.filter_by(subscribe=1).paginate(int(page),int(items_per_page),False).items    
    pagination = Pagination(int(page), int(items_per_page), int(User.query.filter_by(subscribe=1).count()))
    return render_template('listing.html',users=ret_users,pagination=pagination,request_url="subscribed")

@app.route('/admin/unsubscribed')
def admin_unsubscribed():
    #app.jinja_env.globals['request_url'] = "unsubscribed"
    page = request.args["page"]
    items_per_page = request.args["per_page"]    
    ret_users = User.query.filter_by(subscribe=0).paginate(int(page),int(items_per_page),False).items    
    pagination = Pagination(int(page), int(items_per_page), int(User.query.filter_by(subscribe=0).count()))
    return render_template('listing.html',users=ret_users,pagination=pagination,request_url="unsubscribed")

@app.route('/admin/blacklist')
def admin_blacklist():
    #app.jinja_env.globals['request_url'] = "blacklist"
    page = request.args["page"]
    items_per_page = request.args["per_page"]    
    ret_users = User.query.filter_by(blacklist=1).paginate(int(page),int(items_per_page),False).items    
    pagination = Pagination(int(page), int(items_per_page), int(User.query.filter_by(blacklist=1).count()))
    return render_template('listing.html',users=ret_users,pagination=pagination,request_url="blacklist",blacklist="true")



# To bulk blacklist 
@app.route('/bulk_blacklist', methods = ['POST'])
def bulk_blacklist():
    #{"email_list":["abcd@yahoo.com","abcd@gmail.com"]}
    try:
        mydict = eval(request.data)
        emails = mydict["email_list"]
        
        for i in range(0,len(emails)):
            
            email = emails[i]
            user = User.query.filter_by(email=email).first()
            if user:        
                user.blacklist = 1
                db.session.commit()

        ret = {"status":200, "message":"Bulk blacklist successfull"}
        return json.dumps(ret)
    except Exception,e:
        ret = {"status":500,"message":str(e)}
        return json.dumps(ret)



# To remove user from blacklist
@app.route('/remove_blacklist', methods = ['POST'])
def remove_blacklist():
    #{"email_list":["abcd@yahoo.com","abcd@gmail.com"]}
    try:        
        mydict = eval(request.data)
        print mydict
        emails = mydict["email_list"]
        
        for i in range(0,len(emails)):
            
            email = emails[i]
            user = User.query.filter_by(email=email).first()
            if user:        
                user.blacklist = 0
                db.session.commit()

        ret = {"status":200, "message":"Blacklisted user removed successfull"}
        return json.dumps(ret)
    except Exception,e:
        ret = {"status":500,"message":str(e)}
        return json.dumps(ret)





'''
# Facebook event application
ACCESS_TOKEN = "EAACEdEose0cBAN6fKThOyMxBBaa4sT367QyHvBbQQjJrdoDgWCJBqIgMxzOLetuZAsjwhjW8SZBgRNuz3gzrDb50ZCjYCKB7GzzhymnB4rtZAt0ePA9eue2ZBprynkeVbg14BjCyWTAcFbNeJRu1aPE2tgS2NFZC3B0lf5ixEIAcvXSJMPNkvy"
graph = facebook.GraphAPI(access_token=ACCESS_TOKEN, version='2.7')
user_events = graph.get_object(id='10153876712651925/events')
event_ids= []
data = user_events['data']
print data
for d in data:
#    print d.keys()
    print (d['id'], d['description'], d['name'], d['rsvp_status'], d['start_time'])
'''

'''
# Icalendar event application
api = PyiCloudService('yeshu.singh26@gmail.com', 'Ashwarya28')
#api.calendar.get_event_detail('CALENDAR', 'EVENT_ID')

#api.calendar.events()


#api.calendar.events()[0].keys()  
 
from_dt = datetime(2017, 4, 30)
to_dt = datetime(2017, 5, 31)
#print api.calendar.events(from_dt, to_dt)[0].keys() 
print api.calendar.events(from_dt, to_dt)
'''

'''
# Outlook calendar events
URL = u'https://outlook.office365.com/EWS/Exchange.asmx'
USERNAME = u'yeshu.singh26@gmail.com'
PASSWORD = u"ashwarya00100728"

# Set up the connection to Exchange
connection = ExchangeNTLMAuthConnection(url=URL,
                                        username=USERNAME,
                                        password=PASSWORD)

service = Exchange2010Service(connection)
print dir(service)
print dir(service.calendar)
print type(service.calendar)
a = service.calendar()
print dir(a)
print "hhhhhhhhhhhh"
print a.list_events(start=timezone("US/Eastern").localize(datetime(2014, 10, 1, 11, 0, 0)),
    end=timezone("US/Eastern").localize(datetime(2014, 10, 29, 11, 0, 0)),
    details=True
)
'''
'''
for event in service.calendar_list.events:
    print "{start} {stop} - {subject}".format(
        start=event.start,
        stop=event.end,
        subject=event.subject
    )
'''

###############################
# Google calender events application
@app.route('/google/events')
def google_events():
  if 'credentials' not in flask.session:
    return flask.redirect(flask.url_for('oauth2callback'))
  credentials = client.OAuth2Credentials.from_json(flask.session['credentials'])
  if credentials.access_token_expired:
    return flask.redirect(flask.url_for('oauth2callback'))
  else:
    #http_auth = credentials.authorize(httplib2.Http())
    #drive = discovery.build('drive', 'v2', http_auth)
    #files = drive.files().list().execute()
    ######################################
    http = credentials.authorize(httplib2.Http())
    service = discovery.build('calendar', 'v3', http=http)

    now = datetime.utcnow().isoformat() + 'Z' # 'Z' indicates UTC time
    print('Getting the upcoming 10 events')
    eventsResult = service.events().list(
        calendarId='primary', timeMin=now, maxResults=10, singleEvents=True,
        orderBy='startTime').execute()
    events = eventsResult.get('items', [])
    return json.dumps(events)


# Google contacts application
@app.route('/google/contacts')
def google_contacts():
  if 'credentials' not in flask.session:
    return flask.redirect(flask.url_for('oauth2callback'))
  credentials = client.OAuth2Credentials.from_json(flask.session['credentials'])
  if credentials.access_token_expired:
    return flask.redirect(flask.url_for('oauth2callback'))
  else:    
    http = credentials.authorize(httplib2.Http())
    service = discovery.build('people', 'v1', http=http, discoveryServiceUrl='https://people.googleapis.com/$discovery/rest')

    print('List 10 connection names')
    results = service.people().connections().list(resourceName='people/me',requestMask_includeField='person.email_addresses,person.names' ).execute()
    connections = results.get('connections', [])    
    return json.dumps(connections)


@app.route('/oauth2callback')
def oauth2callback():
    #redirect_url = flask.url_for('oauth2callback', _external = True) + '?' + request.query_string
    
   flow = client.flow_from_clientsecrets(
       'client_secret.json',
       scope="https://www.googleapis.com/auth/calendar https://www.googleapis.com/auth/contacts.readonly",
       redirect_uri=flask.url_for('oauth2callback', _external=True)
       )
   if 'code' not in flask.request.args:
    auth_uri = flow.step1_get_authorize_url()
    return flask.redirect(auth_uri)
   else:
    auth_code = flask.request.args.get('code')
    credentials = flow.step2_exchange(auth_code)
    flask.session['credentials'] = credentials.to_json()
    
    return flask.redirect(flask.url_for('google_events'))
    

    '''
    url = atom.http_core.ParseUri(redirect_url)
    auth_token.get_access_token(url.query)
    client = gdata.contacts.client.ContactsClient(source='Clipse')
    auth_token.authorize(client)
    feed = client.GetContacts()
    return feed
    '''



###############################


# Outlook calendar application
outlook_scopes = [ 'openid', 
           'https://outlook.office.com/mail.read',
           'https://outlook.office.com/calendars.read' ]

# Client ID and secret
outlook_client_id = 'b14ddc16-48f9-4a9c-bd76-14c4a9a23c7f'
outlook_client_secret = 'nRrNirwiTh37onokM0bkaNG'

# Constant strings for OAuth2 flow
# The OAuth authority
authority = 'https://login.microsoftonline.com'

# The authorize URL that initiates the OAuth2 client credential flow for admin consent
authorize_url = '{0}{1}'.format(authority, '/common/oauth2/v2.0/authorize?{0}')

# The token issuing endpoint
token_url = '{0}{1}'.format(authority, '/common/oauth2/v2.0/token')

# The scopes required by the app
@app.route("/login/outlook")
def outlook_login():
  #redirect_uri = request.build_absolute_uri(reverse('tutorial:gettoken'))
  redirect_uri=flask.url_for('get_access_token')
  sign_in_url = get_signin_url(redirect_uri)
  return render_template_string('<a href="' + sign_in_url +'">Click here to sign in and view your mail</a>')


def get_signin_url(redirect_uri):
  # Build the query parameters for the signin url
  params = { 'client_id': outlook_client_id,
             'redirect_uri': redirect_uri,
             'response_type': 'code',
             'scope': ' '.join(str(i) for i in outlook_scopes)
            }
            
  signin_url = authorize_url.format(urlencode(params))
  
  return signin_url

def get_token_from_refresh_token(refresh_token, redirect_uri):
  # Build the post form for the token request
  post_data = { 'grant_type': 'refresh_token',
                'refresh_token': refresh_token,
                'redirect_uri': redirect_uri,
                'scope': ' '.join(str(i) for i in scopes),
                'client_id': outlook_client_id,
                'client_secret': outlook_client_secret
              }
              
  r = requests.post(token_url, data = post_data)
  
  try:
    return r.json()
  except:
    return 'Error retrieving token: {0} - {1}'.format(r.status_code, r.text)

@app.route("/outlook")
def get_access_token(redirect_uri):
  current_token = request.session['access_token']
  expiration = request.session['token_expires']
  now = int(time.time())
  if (current_token and now < expiration):
    #Token still valid
    return current_token
  else:
    #Token expired
    refresh_token = request.session['refresh_token']
    new_tokens = get_token_from_refresh_token(refresh_token, redirect_uri)

    #Update session
    # expires_in is in seconds
    # Get current timestamp (seconds since Unix Epoch) and
    # add expires_in to get expiration time
    # Subtract 5 minutes to allow for clock differences
    expiration = int(time.time()) + new_tokens['expires_in'] - 300
    
    # Save the token in the session
    request.session['access_token'] = new_tokens['access_token']
    request.session['refresh_token'] = new_tokens['refresh_token']
    request.session['token_expires'] = expiration

    return new_tokens['access_token']

def get_my_events(access_token, user_email):
  get_events_url = outlook_api_endpoint.format('/Me/Events')

  # Use OData query parameters to control the results
  #  - Only first 10 results returned
  #  - Only return the Subject, Start, and End fields
  #  - Sort the results by the Start field in ascending order
  query_parameters = {'$top': '10',
                      '$select': 'Subject,Start,End',
                      '$orderby': 'Start/DateTime ASC'}

  r = make_api_call('GET', get_events_url, access_token, user_email, parameters = query_parameters)

  if (r.status_code == requests.codes.ok):
    return r.json()
  else:
    return "{0}: {1}".format(r.status_code, r.text)

@app.route('/outlook/events')
def events():
  access_token = get_access_token(request, request.build_absolute_uri(reverse('tutorial:gettoken')))
  user_email = request.session['user_email']
  # If there is no token in the session, redirect to home
  if not access_token:
    return HttpResponseRedirect(reverse('tutorial:home'))
  else:
    events = get_my_events(access_token, user_email)
    context = { 'events': events['value'] }
    return render(request, 'tutorial/events.html', context)



##################################
'''
# Facebook events application
FB_CLIENT_ID  = "136430806467361" 
FB_CLIENT_SECRET = "7ae9e482bf9e4e5ce357718e9b179a83"

# rauth OAuth 2.0 service wrapper
graph_url = 'https://graph.facebook.com/'

facebook_obj = OAuth2Service(name='facebook',
                        authorize_url='https://www.facebook.com/dialog/oauth',
                        access_token_url=graph_url + 'oauth/access_token',
                        client_id=FB_CLIENT_ID,
                        client_secret=FB_CLIENT_SECRET,
                        base_url=graph_url)


@app.route('/login/facebook')
def login_facebook():

    redirect_uri = url_for('authorized', _external=True)

    params = {'redirect_uri': redirect_uri}

    return redirect(facebook_obj.get_authorize_url(**params))




@app.route('/facebook/authorized')

def authorized():

    # check to make sure the user authorized the request

    if not 'code' in request.args:

        flash('You did not authorize the request')

        return redirect(url_for('index'))



    # make a request for the access token credentials using code

    redirect_uri = url_for('authorized', _external=True)

    data = dict(code=request.args['code'], redirect_uri=redirect_uri)

    session = facebook_obj.get_auth_session(data=data, decoder=json.loads)

    # the "me" response

    me = session.get('me').json()

    graph_id = me['id'] 
    ACCESS_TOKEN = session.access_token
    graph = facebook.GraphAPI(access_token=ACCESS_TOKEN, version='2.7')
    user_events = graph.get_object(id= graph_id + '/events')
    event_ids= []
    data = user_events['data']
    print len(data)
    for d in data:
        print d.keys()
        print (d['id'], d['description'], d['name'], d['rsvp_status'], d['start_time'])

#    User.get_or_create(me['username'], me['id'])
    
    flash('Logged in as ' + me['name'])

    return redirect(url_for('index'))

'''

'''
# Google contacts application
#Contacts client id =  153230217988-j17rtl2ov5t5ph8v3vlc55a2prthr0bj.apps.googleusercontent.com 
#Contacts client secrets  = 9JVg308NDJvi1bTymsoGVChS

CLIENT_ID = '153230217988-j17rtl2ov5t5ph8v3vlc55a2prthr0bj.apps.googleusercontent.com '  
CLIENT_SECRET = '9JVg308NDJvi1bTymsoGVChS'
  
SCOPE = 'https://www.google.com/m8/feeds/'
USER_AGENT = 'user_agent'          # request.get.user_agent.          

auth_token = gdata.gauth.OAuth2Token(
    client_id= CLIENT_ID, client_secret= CLIENT_SECRET,
    scope=SCOPE, user_agent=USER_AGENT)

APPLICATION_REDIRECT_URI = 'http://yeshu.clipse.ai:5000/oauth2callback'
authorize_url = auth_token.generate_authorize_url(
    redirect_uri=APPLICATION_REDIRECT_URI)

print authorize_url

# redirect_url = 'http://yeshu.clipse.ai:5000/oauth2callback?code=' + auth_token
# url = atom.http_core.ParseUri(redirect_url)
# auth_token.get_access_token(url.query)


# redirect_url = atom.http_core.Uri.parse_uri(self.request.uri)

# client = gdata.contacts.service.ContactsService(source='clipse contacts ')
# auth_token.authorize(client)

'''





# Facebook user events application
@app.route('/facebook/events')
def facebook_events():
    
    url_events = "https://graph.facebook.com/" + session["facebook_id"] + "/events?access_token=" + session["facebook_token"]
    print url_events
    val = urllib.urlopen(url_events)
    
    
    return json.dumps(val.read())




'''
# Facebook friends list application
@app.route('/facebook/friends')
def facebook_friends():
    


'''



    






#app = Flask(__name__, template_folder='views/'templates')
#app = Flask(__name__)
# app.config.from_object(__name__)
#app.config.from_object('config')
from app import router
db.create_all()
# app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:////home/dell/vagupu/test'



