#This is for welcome email content.
#

def get_html_content(email):
  html_content = '''
  <html>
  <head>
  <title>Clipse.ai - Thanks For Subscribe</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
  .para{
    padding-left:50px;
    padding-right:50px;
  }
  .tableWidth{
    width: 75%;
  }
  @media(max-width:768px) {
  .para{
  padding-left:30px;
  padding-right:30px;
  }
  .tableWidth{
    width: 100%;
  }
  .welcomeFont{
    font-size: 30px!important;
  }
  .subHeading{
    font-size: 20px!important;
  }
  .logo{
    width: 45px;
    text-align: center;
  }
  }
  </style>
  </head>
  <body style="background-color:#DCDEE0;">
    
    <!-- Table for the email content -->
    <table border="0" align="center" class="tableWidth" style=" border-radius:5px; background-color:white; margin-top:40px;" >
      <tbody>
        <!-- Logo section -->
        <tr >
          <td  ><img class="logo" src="https://stage.clipse.ai/static/images/clipse.png" width="75px" alt="clipse.ai" style="margin-left:0px;"></td>
        </tr>
        <!--end of logo -->
        <!-- Welcome Section -->
        <tr>
          <td class="para welcomeFont" style=" text-align:center; font-size:40px; font-family:helvetica;font-weight: 100; padding-bottom: 30px; padding-top: 30px;">Welcome to Clipse.ai
          <br><p style="font-weight: 100; font-size: 25px;" class="subHeading">A revolution in mobile planning.
              </p>
          <td>
        </tr><!--end of welcome heading -->
        <!-- Greeting Section -->
       <tr>
          <td class="para"><p style="font-family:helvetica;font-size:14px;" >Hi,<p><td>
        </tr><!--end of dear Sara -->
        <!-- Mail body section  -->
        <tr>
          <td class="para" style="font-family:helvetica;font-size:14px; line-height:1.5;text-align:left;padding-top:20px;">Thank you for being an early adopter! You are receiving this message because you expressed interest in the first release of Clipse (beta).  We believe that technology should improve our connections to one another, and your participation in the beta program is a valuable contribution to that vision.
        </tr><!--end of paragraph -->
        <!-- Thnaks section -->
        <tr>
          <td class="para"> <p style=" font-family:helvetica;font-size:14px;text-align:left;padding-top:20px; line-height:1.5">Sincerly,<br>Neo & Eric<br>Clipse.ai Co-founders</p></td>
        </tr><!--end of sincerly yours -->
        <tr></tr>
        <tr></tr>
        <tr></tr>
        <tr></tr>
        <tr></tr>
        <tr></tr>
        <tr></tr>
        <tr></tr>
      </tbody>
    </table>
    <!-- End of the table conetent -->
   <table border="0"   align="center" style="border-radius:10px;" >
       
        <tr><td style="text-align:center; padding:20px; font-size:12px; font-family:helvetica;color:#919191 ;">Copyright &copy; 2017 Ephemeryde Inc, Salt Lake City, Utah,1804
     </td></tr><!--end of copyright -->
       <tr><td style=" text-align:center;padding:20px;font-size:12px;font-family:helvetica;">
      <!-- <a href="#" style="text-decoration:none;color:#919191 ;">Privacy Policy  </a>  | <a href="#" style="text-decoration:none;color:#919191 ;">  Terms & condition   </a>|  <a href="#" style="text-decoration:none;color:#919191 ;"> Support  </a> |  <a href="#" style="text-decoration:none;color:#919191 ;"> Account  </a> | <a href="#" style="text-decoration:none;color:#919191 ;">  Subscribe  </a> |   -->
        <a href="https://stage.clipse.ai/unsubscribe/''' + email + '''" style="text-decoration:none;color:#919191 ;"> Unsubscribe   </a>
       </td></tr><!--end of links -->
   <tr><td style="text-align:center;"><a href="https://www.facebook.com/ClipseAI/"><img src="https://clipse.ai/static/images/faceBookIcon.png" width="20px"alt="facebook" style="padding-right:30px;padding-top:20px;padding-bottom:20px;"></a><a href="https://twitter.com/ClipseAI"><img src="https://clipse.ai/static/images/twitterIcon.png" width="20px"alt="twitter" style="padding-top:20px;padding-bottom:20px;"></a><a href="https://www.linkedin.com/company/17973020"><img src="https://clipse.ai/static/images/linkedInIcon.png"alt="linkedin" width="20px"style="padding-left:30px;padding-top:20px;padding-bottom:20px;"></a>
   </td></tr><!--end of social links -->
   </table>
  
  
  
  </body>
 </html>
  '''
  return html_content 

