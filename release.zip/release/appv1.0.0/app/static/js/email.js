function allLinked(){
	if(document.getElementById("subject").value==""){
		window.alert("Please fill out the subject field");
		return true;
	}
	if(document.getElementById("email").value==""){
		window.alert("Please fill out the email field");
		return true;
	}
	if(document.getElementById("salutation").value==""){
		window.alert("Please fill out the salutation field");
		return true;
	}
	if(document.getElementById("msg").value==""){
		window.alert("Please fill out the message field");
		return true;
	}
	if(document.getElementById("signature").value==""){
		window.alert("Please fill out the signature field");
		return true;
	}
	var obj = {};
	["subject","email","salutation","msg","signature"].map(function(id) {
		obj[id] = document.querySelector("#" + id).value;
	});
	console.log("Done!", obj);
	window.alert("Your message posted successfully");
	
	
}

