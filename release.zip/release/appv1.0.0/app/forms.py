from flask_wtf import Form
from wtforms import StringField, BooleanField
from wtforms.validators import DataRequired, Email

class LoginForm(Form):
    email = StringField('email', validators=[DataRequired(), Email()])
    
class PasswordForm(Form):
    password = StringField('Password', validators=[DataRequired()])


