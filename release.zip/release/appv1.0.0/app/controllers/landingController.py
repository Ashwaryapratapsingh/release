#from app import app
#from flask import render_template, request, redirect, render_template, session, url_for


#def loginPage():
	#return render_template('login.html')
